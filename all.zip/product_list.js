function click(){
    let name="TABLE"
    document.getElementById("pname").innerHTML=name;
    
    
}